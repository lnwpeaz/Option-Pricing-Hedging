"""Planned self-financing short-call hedge ledger and terminal settlement. Not implemented."""
