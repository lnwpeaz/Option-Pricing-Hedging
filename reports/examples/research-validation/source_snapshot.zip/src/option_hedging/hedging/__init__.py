"""Hedging package scaffold; numerical features are not implemented."""
