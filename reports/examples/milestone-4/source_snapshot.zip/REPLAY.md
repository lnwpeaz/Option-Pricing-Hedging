# Replay this captured source

Extract into a new directory. Use the recorded Python/platform and dependencies.
A dependency version list is not a portable, hash-verified environment lock.

```sh
PYTHONPATH=src python -m option_hedging.experiments.hedge_demo --config input_config.toml --output-dir replay-output
```

Numerical results target the recorded environment; elapsed times and images may differ.
