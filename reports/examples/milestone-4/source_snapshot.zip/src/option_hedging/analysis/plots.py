"""Planned research figures returned to the caller for saving. Not implemented."""
