"""Planned replication-error, cost and turnover summaries. Not implemented."""
